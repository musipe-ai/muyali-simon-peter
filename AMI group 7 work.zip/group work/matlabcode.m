% =====================================================================
% numerical_methods_all.m
% Runs Secant, Newton-Raphson and RK4 (each with FOR and WHILE loops)
% on Problems A, B, C, D in one go.
% Just press Run. (Needs MATLAB R2016b or newer: functions are at the end.)
% =====================================================================

tol = 1e-6;  N = 50;

% ---------- Problems ----------
f1 = @(x) x.^3 - x - 2;    df1 = @(x) 3*x.^2 - 1;      % A: x^3 - x - 2 = 0
f2 = @(x) cos(x) - x;      df2 = @(x) -sin(x) - 1;     % B: cos(x) - x = 0
g1 = @(x, y) x + y;            e1 = @(x) 2*exp(x) - x - 1;           % C: dy/dx = x + y, y(0)=1
g2 = @(x, y) y - x.^2 + 1;     e2 = @(x) (x + 1).^2 - 0.5*exp(x);    % D: dy/dx = y - x^2 + 1, y(0)=0.5

hdr  = '  i        x_i          f(x_i)        error\n';
row  = '%3d %12.6f %12.3e %12.3e\n';
ohdr = '  i     x         y\n';
orow = '%3d %6.2f %12.6f\n';

% ---------- Secant ----------
fprintf('===== SECANT METHOD =====\n');
fprintf('--- Problem A, for loop ---\n');    fprintf(hdr); fprintf(row, secant_for(f1, 1, 2, tol, N)');
fprintf('--- Problem A, while loop ---\n');  fprintf(hdr); fprintf(row, secant_while(f1, 1, 2, tol, N)');
fprintf('--- Problem B, for loop ---\n');    fprintf(hdr); fprintf(row, secant_for(f2, 0, 1, tol, N)');
fprintf('--- Problem B, while loop ---\n');  fprintf(hdr); fprintf(row, secant_while(f2, 0, 1, tol, N)');

% ---------- Newton-Raphson ----------
fprintf('\n===== NEWTON-RAPHSON METHOD =====\n');
fprintf('--- Problem A, for loop ---\n');    fprintf(hdr); fprintf(row, newton_for(f1, df1, 1.5, tol, N)');
fprintf('--- Problem A, while loop ---\n');  fprintf(hdr); fprintf(row, newton_while(f1, df1, 1.5, tol, N)');
fprintf('--- Problem B, for loop ---\n');    fprintf(hdr); fprintf(row, newton_for(f2, df2, 1.0, tol, N)');
fprintf('--- Problem B, while loop ---\n');  fprintf(hdr); fprintf(row, newton_while(f2, df2, 1.0, tol, N)');

% ---------- Runge-Kutta 4 ----------
fprintf('\n===== RUNGE-KUTTA 4 =====\n');
fprintf('--- Problem C, for loop ---\n');    fprintf(ohdr); fprintf(orow, rk4_for(g1, 0, 1, 0.1, 5)');
fprintf('--- Problem C, while loop ---\n');  fprintf(ohdr); fprintf(orow, rk4_while(g1, 0, 1, 0.1, 0.5)');
fprintf('Exact y(0.5) = %.6f\n', e1(0.5));
fprintf('--- Problem D, for loop ---\n');    fprintf(ohdr); fprintf(orow, rk4_for(g2, 0, 0.5, 0.2, 5)');
fprintf('--- Problem D, while loop ---\n');  fprintf(ohdr); fprintf(orow, rk4_while(g2, 0, 0.5, 0.2, 1.0)');
fprintf('Exact y(1.0) = %.6f\n', e2(1.0));

% ---------- Summary ----------
a1 = secant_for(f1,1,2,tol,N);   a2 = secant_for(f2,0,1,tol,N);
b1 = newton_for(f1,df1,1.5,tol,N); b2 = newton_for(f2,df2,1.0,tol,N);
c1 = rk4_for(g1,0,1,0.1,5);      d1 = rk4_for(g2,0,0.5,0.2,5);
fprintf('\n===== SUMMARY =====\n');
fprintf('A  Secant : %.6f (%d iterations)\n', a1(end,2), size(a1,1));
fprintf('A  Newton : %.6f (%d iterations)\n', b1(end,2), size(b1,1));
fprintf('B  Secant : %.6f (%d iterations)\n', a2(end,2), size(a2,1));
fprintf('B  Newton : %.6f (%d iterations)\n', b2(end,2), size(b2,1));
fprintf('C  RK4 y(0.5) = %.6f  (exact %.6f)\n', c1(end,3), e1(0.5));
fprintf('D  RK4 y(1.0) = %.6f  (exact %.6f)\n', d1(end,3), e2(1.0));

% =====================================================================
% Local functions (must stay at the end of the file)
% =====================================================================

function hist = secant_for(f, x0, x1, tol, N)
% Secant method with a FOR loop. Each row of hist: [i, x, f(x), error]
hist = [];
for i = 1:N
    x2  = x1 - f(x1)*(x1 - x0)/(f(x1) - f(x0));
    err = abs(x2 - x1);
    hist(end+1, :) = [i, x2, f(x2), err];
    x0 = x1;
    x1 = x2;
    if err < tol
        break
    end
end
end

function hist = secant_while(f, x0, x1, tol, N)
% Secant method with a WHILE loop. Each row of hist: [i, x, f(x), error]
hist = [];
i = 0;
err = tol + 1;
while err >= tol && i < N
    x2  = x1 - f(x1)*(x1 - x0)/(f(x1) - f(x0));
    err = abs(x2 - x1);
    i   = i + 1;
    hist(end+1, :) = [i, x2, f(x2), err];
    x0 = x1;
    x1 = x2;
end
end

function hist = newton_for(f, df, x0, tol, N)
% Newton-Raphson method with a FOR loop. Each row of hist: [i, x, f(x), error]
hist = [];
x = x0;
for i = 1:N
    xnew = x - f(x)/df(x);
    err  = abs(xnew - x);
    hist(end+1, :) = [i, xnew, f(xnew), err];
    x = xnew;
    if err < tol
        break
    end
end
end

function hist = newton_while(f, df, x0, tol, N)
% Newton-Raphson method with a WHILE loop. Each row of hist: [i, x, f(x), error]
hist = [];
x = x0;
i = 0;
err = tol + 1;
while err >= tol && i < N
    xnew = x - f(x)/df(x);
    err  = abs(xnew - x);
    i    = i + 1;
    hist(end+1, :) = [i, xnew, f(xnew), err];
    x = xnew;
end
end

function hist = rk4_for(f, x0, y0, h, n)
% Runge-Kutta 4th order with a FOR loop. Each row of hist: [i, x, y]
hist = [0, x0, y0];
x = x0;
y = y0;
for i = 1:n
    k1 = f(x, y);
    k2 = f(x + h/2, y + h*k1/2);
    k3 = f(x + h/2, y + h*k2/2);
    k4 = f(x + h,   y + h*k3);
    y = y + h*(k1 + 2*k2 + 2*k3 + k4)/6;
    x = x0 + i*h;
    hist(end+1, :) = [i, x, y];
end
end

function hist = rk4_while(f, x0, y0, h, xend)
% Runge-Kutta 4th order with a WHILE loop. Each row of hist: [i, x, y]
hist = [0, x0, y0];
x = x0;
y = y0;
i = 0;
while x < xend - 1e-12
    k1 = f(x, y);
    k2 = f(x + h/2, y + h*k1/2);
    k3 = f(x + h/2, y + h*k2/2);
    k4 = f(x + h,   y + h*k3);
    y = y + h*(k1 + 2*k2 + 2*k3 + k4)/6;
    x = x + h;
    i = i + 1;
    hist(end+1, :) = [i, x, y];
end
end
